<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once('Platform/Data.php');
require_once('Platform/Data/LessonTypes/LessonType.php');

/**
 *
 */
Class Platform_Data_LessonTypes extends Platform_Data{
}
?>