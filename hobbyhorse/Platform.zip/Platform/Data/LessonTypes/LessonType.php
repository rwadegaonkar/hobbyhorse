<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
require_once("Platform/Data/Base.php");

class Platform_Data_LessonTypes_LessonType extends Platform_Data_Base {
    
}

?>