<?php
/**
 * User: radhika\
 * To change this template use File | Settings | File Templates.
 */
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once('Platform/Data.php');
require_once('Platform/Data/Lessons/Lesson.php');

/**
 *
 */
Class Platform_Data_Lessons extends Platform_Data{
}
